- Abre la terminal en la carpeta de Haskell donde tengas el proyecto

Ejecuta, si trabajas en MAC o linux, los siguientes comandos en la terminal:
- Compila el código
ghc -o main Main.hs

- Ejecuta el programa
./main

